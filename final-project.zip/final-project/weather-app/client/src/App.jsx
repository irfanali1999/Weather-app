import { useState } from 'react';
import axios from 'axios';
import './App.css'; // CSS for professional styling

function App() {
    const [city, setCity] = useState('');
    const [weather, setWeather] = useState(null);
    const [error, setError] = useState('');

    const getWeather = async () => {
        try {
            const response = await axios.get(`http://localhost:5000/weather?city=${city}`);
            setWeather(response.data);
            setError('');
        } catch (err) {
            setWeather(null);
            setError('Unable to retrieve weather data.');
        }
    };

    return (
        <div className="app-wrapper">
            <div className="weather-card">
                <h1 className="app-title">Weather Forecast</h1>
                <p className="app-subtitle">Get the latest weather updates</p>

                <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="Enter city name"
                    className="input-field"
                />

                <button className="get-weather-btn" onClick={getWeather}>
                    Check Weather
                </button>

                {error && <p className="error-message">{error}</p>}

                {weather && (
                    <div className="weather-info">
                        <h2 className="weather-city">{weather.name}</h2>
                        <p className="weather-temp">{weather.main.temp}°C</p>
                        <p className="weather-desc">{weather.weather[0].description}</p>
                        <div className="extra-info">
                            <p>Humidity: {weather.main.humidity}%</p>
                            <p>Wind: {weather.wind.speed} km/h</p>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}

export default App;
